import sys
import logging
import rds_config
import pymysql
import json
import rqs_type
import swSql

#rds settings
rds_host  = rds_config.db_endPoint
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name
port = rds_config.db_port

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(host=rds_host, port=port, user=name, password=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()
    
    

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")

def lambda_handler(event, context):
    
    requestType = event["requestType"] # 요청 타입
    param = event["param"] # 파라미터 값
    result = "null" # 리턴값
    
    if requestType == rqs_type.TEST: # 테스트 요청 시
        return {
            'statusCode': 200,
            'body': json.dumps('test done')
        }

    
    elif requestType == rqs_type.REGISTER: # 회원가입 요청 
        result = swSql.user_register(conn, param)
    
    elif requestType == rqs_type.EXIST_ID: # 아이디 존재 확인 요청
        result = swSql.exist_id(conn, param)
    
    elif requestType == rqs_type.EXIST_EMAIL: # 이메일 존재 확인 요청
        result = swSql.exist_email(conn, param)
        
    elif requestType == rqs_type.INSTANT_LOGIN: # 로그인 성공 확인 요청
        result = swSql.instant_login(conn, param)
        
    elif requestType == rqs_type.FIND_ID: # 아이디 찾
        result = swSql.find_id(conn, param)
            
    
    # return result 
    return {
        'statusCode': 200,
        'body': json.dumps('succeeded'),
        'result': json.dumps(result)
    }
    
# with open('C:/Users/wjswo/Desktop/Study/pythonWorkspace/mysql_test/test_data/exist_id.json', 'r') as f:
#     json_data = json.load(f)

# print(json.dumps(json_data) )

# result = lambda_handler(json_data, None)
# print(result)

    