
# 아이디 존재여부 확인
# 입력: 확인할 id
# 출력: 해당 id 와 일치하는 사용자 정보 수
def exist_id(conn, param):
    try:
        id = param["id"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "SELECT user_id FROM user_info WHERE user_id = '"+id+"'" 
            cur.execute( nowSql )  
            conn.commit()
            tmpResult = cur.fetchall()
    
        result = len(tmpResult)
        
    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result
    
    
# 아이디 찾기
# 입력: 이메일 주소
# 출력: 해당 이메일 주소로 가입된 아이디
def find_id(conn, param):
    try:
        email = param["email"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "SELECT user_id FROM user_info WHERE email = '"+email+"'" 
            cur.execute( nowSql )  
            conn.commit()
            resultSet = cur.fetchall()
            
            if resultSet != None:
                user_id = resultSet[0][0] # 0번 행의 0열 값
                
            if user_id != None:
                result = user_id
            else:
                result = "NO_MATCH" 
        
    except:
        result = "NO_MATCH"
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result
    
    
# 이메일 존재여부 확인
# 입력: 이메일 주소
# 출력: 해당 이메일이 있는 데이터 개수
def exist_email(conn, param):
    try:
        email = param["email"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "SELECT user_id FROM user_info WHERE email = '"+email+"'" 
            cur.execute( nowSql )  
            conn.commit()
            tmpResult = cur.fetchall()
    
        result = len(tmpResult)
        
        
    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result
    
    

# 로그인
# 입력: id, pw
# 출력: 올바른 id,pw 확인
def instant_login(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "SELECT user_pw FROM user_info WHERE user_id = '"+id+"'"  # 패스워드 받아오기
            cur.execute( nowSql )  
            conn.commit()
            resultSet = cur.fetchall() # 결과
            
            if resultSet != None:
                user_pw = resultSet[0][0] # 0번 행의 0열 값
            
            
            
            if user_pw != None and user_pw == pw:
                result = "LOGIN_SUCCEED" 
            else:
                result = "LOGIN_FAIL" 
                
        
    except:
        result = "LOGIN_FAIL" 
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result

    
# 회원가입
# 입력: id, pw, 이메일, 주소, 닉네임, 연령
# 출력: 성공 여부
def user_register(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
        email = param["email"]
        nickname = param["nickname"]
        phone = param["phone"]
    except:
        return "parameter error"

    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "INSERT INTO user_info values(" + "'"+id +"',"+  "'"+pw +"',"+ "'"+email +"'," + "'"+nickname +"'," +  "'"+phone +"')" 
            cur.execute( nowSql )  
            conn.commit()
            
        result = True
    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
    
    
# 디바이스 접근 요청
# 입력: id, pw
# 출력: 성공 여부 boolean
def device_access_test(conn, device_id, device_pw):
    

    allowAccess = False
    
    try:
        id = device_id
        pw = device_pw
    except:
        return allowAccess
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "SELECT device_pw FROM device_info WHERE device_id = "+id+"" 
            cur.execute( nowSql )  
            conn.commit()
            resultSet = cur.fetchall()
            
            if resultSet != None:
                collect_pw = resultSet[0][0] # 0번 행의 0열 값
                
            if collect_pw != None and str(pw) == str(collect_pw):
                allowAccess = True
                
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")
        allowAccess = False
    
    return allowAccess
    
    
# 디바이스 정보 가져오기
# 입력: 디바이스 id, pw
# 출력: 디바이스 정보
def get_device_info(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        if device_access_test(conn, id ,pw):
            with conn.cursor() as cur:
                nowSql = "SELECT ward_name, ward_age, ward_address, ward_description FROM device_info WHERE device_id = '"+id+"'" 
                cur.execute( nowSql )  
                conn.commit()
                resultSet = cur.fetchall()
                
                result = resultSet
        else:
            result = "DENIED ACCESS"
        
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result 
    

    
# 문열림 로그 가져오기
# 입력: 디바이스 id, pw
# 출력: 디바이스 정보
def get_door_logs(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        if device_access_test(conn, id, pw):
            with conn.cursor() as cur:
                nowSql = "SELECT * FROM door_log WHERE device_id = '"+id+"'" 
                cur.execute( nowSql )  
                conn.commit()
                resultSet = cur.fetchall()
                
                result = resultSet
                print(type(result))
        else:
            result = "DENIED ACCESS"
        
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result  
    

# 스피커 로그 가져오기
# 입력: 디바이스 id, pw
# 출력: 디바이스 정보
def get_speaker_logs(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        if device_access_test(conn, id, pw):
            with conn.cursor() as cur:
                nowSql = "SELECT * FROM ai_speaker_log WHERE device_id = '"+id+"'" 
                cur.execute( nowSql )  
                conn.commit()
                resultSet = cur.fetchall()
                
                result = resultSet
        else:
            result = "DENIED ACCESS"
        
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result  
    
    
# 사용자 계정 패스워드 변경 // login 과 함께 사용.
# 입력: id,new_pw
# 출력: 성공여부
def user_password_update(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "UPDATE user_info SET user_pw = '" + pw + "' WHERE user_id = '" + id + "'" # 패스워드 변경
            cur.execute( nowSql )
            conn.commit()
            resultSet = cur.fetchall() # 결과
            
            result = "PW_UPDATE_SUCCEED" 
    except:
        result = "PW_UPDATE_FAIL"
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
    
    
    
# 사용자 접근 요청
# 입력: id, pw
# 출력: 성공 여부 boolean
def user_access_test(conn, user_id, user_pw):

    allowAccess = False
    
    try:
        id = user_id
        pw = user_pw
    except:
        return allowAccess
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "SELECT user_pw FROM user_info WHERE user_id = '"+id+"'" 
            cur.execute( nowSql )  
            conn.commit()
            resultSet = cur.fetchall()
            
            if resultSet != None:
                collect_pw = resultSet[0][0] # 0번 행의 0열 값
                
            if collect_pw != None and str(pw) == str(collect_pw):
                allowAccess = True
                
                
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")
        allowAccess = False
    
    return allowAccess

    
# 사용자 정보 가져오기
# 입력: 사용자 id, pw
# 출력: 사용자 정보
def get_user_info(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        if user_access_test(conn, id, pw):
            with conn.cursor() as cur:
                nowSql = "SELECT email, user_name, phone FROM user_info WHERE user_id = '"+id+"'" 
                cur.execute( nowSql )  
                conn.commit()
                resultSet = cur.fetchall()
                
                result = resultSet
        else:
            result = "DENIED ACCESS"
        
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result 
    
# 디바이스 목록 가져오기
# 입력: 사용자 id, pw
# 출력: 디바이스 목록
def get_device_list(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        if user_access_test(conn, id, pw):
            with conn.cursor() as cur:
                nowSql = "SELECT device_id, device_pw FROM user_device_info WHERE user_id = '" + id + "'"
                cur.execute(nowSql)
                conn.commit()
                resultSet = cur.fetchall()
                
                result = resultSet
        else:
            result = "DENIED ACCESS"
        
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result 
    
    
# 디바이스 등록
# 입력: 사용자 id, 사용자 pw, 디바이스 id, pw
# 출력: 성공 여부
def device_add(conn, param):
    try:
        user_id = param["user_id"]
        user_pw = param["user_pw"]
        device_id = param["device_id"]
        device_pw = param["device_pw"]
        
    except:
        return "parameter error"

    try:
        nowSql = ""
        
        if user_access_test(conn, user_id, user_pw) and device_access_test(conn, device_id, device_pw): # 사용자 및 디바이스 모두 인증 성공해야함
            
            with conn.cursor() as cur:
                nowSql = "INSERT INTO user_device_info values(" + "'"+user_id +"',"+  "'"+device_id +"'," +  "'"+device_pw +"')" 
                cur.execute( nowSql )  
                conn.commit()
                
            result = "DEVICE_ADD_SUCCEED"
            
        else:
            result = "DENIED ACCESS"
    except:
        result = "DEVICE_ADD_FAIL"
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
    
# 디바이스 인증
# 입력: id, pw
# 출력: 올바른 id,pw 확인
def device_credential(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
    except:
        return "parameter error"
    
    try:
        nowSql = ""
        
        with conn.cursor() as cur:
  
            nowSql = "SELECT device_pw FROM device_info WHERE device_id = "+id+""  # 패스워드 받아오기
            cur.execute( nowSql )  
            conn.commit()
            resultSet = cur.fetchall() # 결과
            
            if resultSet != None:
                device_pw = resultSet[0][0] # 0번 행의 0열 값

            
            if device_pw != None and str(device_pw) == pw:
                result = "DEVICE_CREDENTIAL_SUCCEED" 
            else:
                result = "DEVICE_CREDENTIAL_FAIL" 
                
        
    except:
        result = "DEVICE_CREDENTIAL_ERROR" 
        print("sql execute error" + " ( " + nowSql + " ) ")
    
    return result
    
    
# 사용자 정보 변경
# 입력: id, pw, 이메일, 주소, 닉네임, 연령
# 출력: 성공 여부
def user_info_update(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
        nickname = param["nickname"]
        phone = param["phone"]
        new_pw = param["new_pw"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        update_pw = pw
        
        if pw != new_pw:
            update_pw = new_pw

        if user_access_test(conn, id, pw): # 인증 성공 시
            with conn.cursor() as cur:
                nowSql = "UPDATE user_info SET user_pw = '" + update_pw + "', user_name = '" + nickname + "', phone = '" + phone + "' WHERE user_id = '" + id + "'"
                cur.execute(nowSql)
                conn.commit()
                
                result = "UserInfo_UPDATE_SUCCEED"
        else:
            result = "DENIED ACCESS"

    except:
        result = "UserInfo_UPDATE_FAIL"
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    

    
# 디바이스 정보 변경
# 입력: id, pw, 이름, 연령, 주소, 특이사항
# 출력: 성공 여부
def device_set_profile(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
        name = param["name"]
        age = param["age"]
        address = param["address"]
        desc = param["desc"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        if device_access_test(conn, id, pw): # 인증 성공 시
            with conn.cursor() as cur:
                nowSql = "UPDATE device_info SET ward_name= '" + name + "', ward_age = '" + age + "', ward_address = '" + address + "', ward_description = '" + desc + "' WHERE device_id = '" + id + "'"
                cur.execute(nowSql)
                conn.commit()
                
                result = "DEVICE_PROFILE_SUCCEED"

        else:
            result = "DENIED ACCESS"

    except:
        result = "DEVICE_PROFILE_FAIL"
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
    
# 디바이스 비밀번호 변경
# 입력: id, pw, new_pw
# 출력: 성공 여부
def device_edit_password(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
        new_pw = param["new_pw"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        update_pw = new_pw

        if device_access_test(conn, id, pw): # 인증 성공 시
            with conn.cursor() as cur:
                nowSql = "UPDATE device_info SET device_pw = '" + update_pw + "' WHERE device_id = '" + id + "'"
                cur.execute(nowSql)
                conn.commit()
                
                result = "DEVICE_EDIT_PASSWORD_SUCCEED"
        else:
            result = "DENIED ACCESS"

    except:
        result = "DEVICE_EDIT_PASSWORD_FAIL"
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
    
    
# 디바이스 삭제
# 입력: user_id, user_pw, device_id
# 출력: 성공 여부
def device_delete(conn, param):
    try:
        user_id = param["user_id"]
        user_pw = param["user_pw"]
        device_id = param["device_id"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        if user_access_test(conn, user_id, user_pw): # 인증 성공 시
            with conn.cursor() as cur:
                nowSql = "DELETE FROM user_device_info WHERE device_id = '" + device_id + "'"
                cur.execute(nowSql)
                conn.commit()

        result = "DEVICE_DELETE_SUCCEED"
    except:
        result = "DEVICE_DELETE_FAIL"
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
    
    # ↓ 아직 미완성
    
    
    

# 회원탈퇴
# 입력: id, pw
# 출력: 성공 여부
def user_info_delete(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]

    except:
        return "parameter error"

    try:
        nowSql = ""
        
        if user_access_test(conn, id, pw): #인증 성공
            with conn.cursor() as cur:
                nowSql = "DELETE FROM user_info WHERE user_id = '"+id +"'"
                cur.execute( nowSql )  
                conn.commit()
            
                result = "UserInfo_DELETE_SUCCEED"
        else:
            result = "UserInfo_DELETE_FAIL"
    except:
        result = "SQL ERROR: " + nowSql
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    

    
#디바이스 등록
# 입력: id, pw, 이름, 연령, 거주지, 특이사항
# 출력: 성공 여부
def device_register(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
        name = param["name"]
        age = param["age"]
        address = param["address"]
        description = param["description"]        
    except:
        return "parameter error"

    try:
        nowSql = ""
        
        with conn.cursor() as cur:
            nowSql = "INSERT INTO device_info values(" + "'"+id +"',"+  "'"+pw +"',"+ "'"+name +"'," +  "'"+age +"'," +  "'"+address +"'," +  "'"+description +"')" 
            cur.execute( nowSql )  
            conn.commit()
            
        result = True
    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result

# 디바이스 정보 수정
# 입력: id, pw, 이름, 연령, 거주지, 특이사항
# 출력: 성공 여부
def device_update(conn, param):
    try:
        id = param["id"]
        pw = param["pw"]
        name = param["name"]
        age = param["age"]
        address = param["address"]
        description = param["description"]
    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "UPDATE device_info SET device_pw = '" + pw + "', ward_name= '" + name + "', ward_age = '" + age + "', ward_address = '" + address + "', ward_description = '" + description + "' WHERE device_id = '" + id + "'"
            cur.execute(nowSql)
            conn.commit()

        result = True
    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result


# 목록정보출력 1 :: 디바이스 대상자 이름 조회
# 입력: device_id
# 출력: ward_name
def device_name(conn, param):
    try:
        id = param["id"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "SELECT DISTINCT ward_name FROM device_info WHERE device_id = '" + id + "'"
            cur.execute(nowSql)
            conn.commit()
            result = cur.fetchall()

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result

# 목록정보출력 2 :: 디바이스 당일 문열림 횟수
# 입력: device_id
# 출력: door_cnt
def device_cnt_door(conn, param):
    try:
        id = param["id"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "SELECT COUNT(*) FROM door_log WHERE device_id = '" + id + "' AND DATE(date) = (SELECT DATE_FORMAT(now(),'%y-%m-%d'))"
            cur.execute(nowSql)
            conn.commit()
            result = cur.fetchall()

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result

# 목록정보출력 3 :: 디바이스 당일 대화 횟수
# 입력: device_id
# 출력: speaker_cnt
def device_cnt_speaker(conn, param):
    try:
        id = param["id"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "SELECT COUNT(*) FROM ai_speaker_log WHERE device_id = '" + id + "' AND DATE(date) = (SELECT DATE_FORMAT(now(),'%y-%m-%d'))"
            cur.execute(nowSql)
            conn.commit()
            result = cur.fetchall()

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result

# 디바이스 door 상세 정보
# 입력: device_id
# 출력: date, place
def device_detail_door(conn, param):
    try:
        id = param["id"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "SELECT date,place FROM door_log WHERE device_id = '" + id + "'"
            cur.execute(nowSql)
            conn.commit()
            result = cur.fetchall()

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result

# 디바이스 ai_speaker 상세 정보
# 입력: device_id
# 출력: date, talk_time
def device_detail_speaker(conn, param):
    try:
        id = param["id"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "SELECT date,talk_time FROM ai_speaker_log WHERE device_id = '" + id + "'"
            cur.execute(nowSql)
            conn.commit()
            result = cur.fetchall()

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    

# 이메일 인증 요청시간 만료 확인
# 입력: email, number
# 출력: 기간 만료 전이면 1, 기간 만료됐을 경우 0
def exist_certificate(conn, param):
    try:
        email = param["email"]
        number = param["number"]

    except:
        return "parameter error"

    try:
        nowSql = ""
        

        with conn.cursor() as cur:
            nowSql = "SELECT COUNT(*) FROM certification WHERE email = '"+email+"'"
            cur.execute(nowSql)
            conn.commit()
            result = cur.fetchall()

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result

    
# 만료 후 이메일 인증 번호 요청
# 입력: email, number
# 출력: 성공 여부
def certificate_ins(conn, param):
    try:
        email = param["email"]
        number = param["number"]

    except:
        return "parameter error"

    try:
        nowSql = ""
        

        with conn.cursor() as cur:
            nowSql = "INSERT INTO certification values('"+email+ "', '"+number+"','"+now() +"')"
            cur.execute(nowSql)
            conn.commit()
            result = True

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
# 만료 전 이메일 인증 번호 요청
# 입력: email, number
# 출력: 성공 여부
def certificate_upd(conn, param):
    try:
        email = param["email"]
        number = param["number"]

    except:
        return "parameter error"

    try:
        nowSql = ""
        

        with conn.cursor() as cur:
            nowSql = "UPDATE certification SET number = '"+number+"' WHERE email = '"+email+"'"
            cur.execute(nowSql)
            conn.commit()
            result = True

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
    
# 이메일 인증 번호 확인
# 입력: email, number
# 출력: 성공 여부
def certification(conn, param):
    try:
        email = param["email"]
        number = param["number"]

    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "SELECT number FROM certification WHERE email = '"+email+"'"
            cur.execute(nowSql)
            conn.commit()
            cert = cur.fetchall()
            if cert == number :
                result = True

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result

# 이메일 인증 번호 삭제
# 입력: email
# 출력: 성공 여부
def certificate_delete(conn, param):
    try:
        email = param["email"]
    except:
        return "parameter error"

    try:
        nowSql = ""

        with conn.cursor() as cur:
            nowSql = "DELETE FROM certification WHERE email = '" + email + "'"
            cur.execute(nowSql)
            conn.commit()
            result = True

    except:
        result = False
        print("sql execute error" + " ( " + nowSql + " ) ")

    return result
