db_username = "admin"
db_password = "safeIOT1!"
db_name = "safefamily"
db_endPoint = "haniumrdsserver2.c2dqflmwrgaf.ap-northeast-2.rds.amazonaws.com"
db_port = 3306