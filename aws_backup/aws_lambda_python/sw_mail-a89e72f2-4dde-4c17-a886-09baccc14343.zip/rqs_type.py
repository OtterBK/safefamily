EMAIL_VERIFY = "email_verify"
CODE_COMPARE = "code_compare"
RESET_PASSWORD = "reset_password"