EMAIL_ADDRESS = "safefamilyiot@gmail.com"
SECRET_KEY = "akffsqcevvasukei"