import sys
import smtplib
from email.mime.text import MIMEText
import rqs_type
import mail_config
import json
import pymysql
import time
import random
import logging
import rds_config


random.seed() #시드 설정

#rds settings
rds_host  = rds_config.db_endPoint
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name
port = rds_config.db_port

logger = logging.getLogger()
logger.setLevel(logging.INFO)


try:
    conn = pymysql.connect(host=rds_host, port=port, user=name, password=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()


def lambda_handler(event, context):
    
    requestType = event["requestType"]
    param = event["param"]
    response_message = ""
    
    # 이메일 인증 코드 보내기
    if requestType == rqs_type.EMAIL_VERIFY:
        
        response_message = 'SEND_CODE_SUCCESS'
        
        try:
            email = param["email"]

            s = smtplib.SMTP('smtp.gmail.com', 587) # 세션 생성
            s.starttls() # TLS 보안 시작
            s.login(mail_config.EMAIL_ADDRESS, mail_config.SECRET_KEY) # 로그인
            
            
            # 전송부
            verify_code = str(random.randrange(100000, 1000000)) # 100000부터 999999 사이의 난수 생성
            
            msg = MIMEText('인증코드 : ' + str(verify_code))
            msg['Subject'] = "Safe Family 회원가입 인증코드입니다."
            
            # 메일 보내기
            s.sendmail(mail_config.EMAIL_ADDRESS, email, msg.as_string())
            
            # 세션 종료
            s.quit()
            
            
            already_verify_code = None
            # 먼저 이미 있는지 조회
            try:
                nowSql = ""
                
                with conn.cursor() as cur:
                    nowSql = "SELECT number FROM certification WHERE email = '"+email+"'"
                    cur.execute( nowSql )  
                    conn.commit()
                    tmpResult = cur.fetchall()
    
                already_verify_code = len(tmpResult)
                    
            except:
                print("sql execute error" + " ( " + nowSql + " ) ")
                
            if already_verify_code > 0:
                
                try:
                    nowSql = ""
                    
                    with conn.cursor() as cur:
                        nowSql = "UPDATE certification SET number = '"+verify_code+"', date = now() WHERE email = '"+email+"'"
                        cur.execute( nowSql )  
                        conn.commit()
                        
                except:
                    print("sql execute error" + " ( " + nowSql + " ) ")
                    
                
            else:
                try:
                    nowSql = ""
                    
                    with conn.cursor() as cur:
                        nowSql = "INSERT INTO certification values('"+email+ "', '"+verify_code+"',now())"
                        cur.execute( nowSql )  
                        conn.commit()
                        
                except:
                    print("sql execute error" + " ( " + nowSql + " ) ")
                
            
            
        except:
            response_message = 'SEND_CODE_FAIL'
            
    
    # 인증코드 확인
    if requestType == rqs_type.CODE_COMPARE:
        
        try:
            isSuc = True
            email = param["email"]
            code = param["code"]

            verify_code = None
            # DB에서 코드 조회
            try:
                nowSql = ""
                
                with conn.cursor() as cur:
                    nowSql = "SELECT number FROM certification WHERE email = '"+email+"'"
                    cur.execute( nowSql )  
                    conn.commit()
                    resultSet = cur.fetchall()
                    
            except:
                print("sql execute error" + " ( " + nowSql + " ) ")
                
            if resultSet != None:
                verify_code = resultSet[0][0]
                
            if verify_code != None:

                if str(code) == str(verify_code): # 코드 일치 시
                    response_message = 'CODE_CONSISTENT'
                else:
                    response_message = 'CODE_INCONSISTENT'
            else:
                response_message = 'CODE_DATA_NULL'
                
            
            
        except:
            isSuc = False
            
    
    # 비밀번호 초기화
    if requestType == rqs_type.RESET_PASSWORD:
        
        try:
            isSuc = True
            email = param["email"]

            # 무작위 비밀번호 생성
            new_pw = str(random.randrange(10000000, 100000000)) # 10000000부터 99999999 사이의 난수 생성
            
            s = smtplib.SMTP('smtp.gmail.com', 587) # 세션 생성
            s.starttls() # TLS 보안 시작
            s.login(mail_config.EMAIL_ADDRESS, mail_config.SECRET_KEY) # 로그인
            
            
            msg = MIMEText('임시 비밀번호 : ' + str(new_pw))
            msg['Subject'] = "비밀번호 초기화 요청에 따른 임시 비밀번호입니다."
            
            # 메일 보내기
            s.sendmail(mail_config.EMAIL_ADDRESS, email, msg.as_string())
            
            # 세션 종료
            s.quit()

            try:
                nowSql = ""
                
                with conn.cursor() as cur:
                    nowSql = "UPDATE user_info SET user_pw ='"+new_pw+ "' WHERE email = '"+email+"'" 
                    cur.execute( nowSql )  
                    conn.commit()
                    resultSet = cur.fetchall()
                    
                    response_message = "RESET_SUCCEED"
                    
            except:
                response_message = "RESET_FAIL"
                print("sql execute error" + " ( " + nowSql + " ) ")
                
            
            
        except:
            isSuc = False
        
    
    return {
        'statusCode': 200,
        'result': json.dumps(response_message),
    }


